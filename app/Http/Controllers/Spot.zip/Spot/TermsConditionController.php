<?php

namespace App\Http\Controllers\Spot;

use App\Http\Controllers\Controller;
use App\Models\TermsCondition;
use Illuminate\Http\Request;
use App\Models\SpotBooking;
use App\Models\SpotPackage;
use App\Models\Spot;
use App\Models\AdditionalService;
use App\Models\SpotDetail;
use Illuminate\Support\Facades\Storage;
use Barryvdh\DomPDF\Facade\Pdf;
use App\Models\Customer;
use App\Models\CustomerType;
use App\Models\FinanceGroup;
use App\Models\FinanceAccount;
use App\Models\FinanceTransaction;
use App\Models\CompanySetting;
use App\Models\Warehouse;
use App\Models\Product;
use App\Models\ProductUnit;
use App\Models\Stock;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Date;
use Validator;
use Carbon\Carbon;
use Auth;
use App\Models\ProductService;
use App\Models\ProductServiceDetail;
use Illuminate\Support\Facades\View;
use NumberFormatter;
use Rmunate\Utilities\SpellNumber;
use Illuminate\Pagination\LengthAwarePaginator;






class TermsConditionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    // public function index()
    // {
    //     $terms = DB::table('terms_conditions')
    //         ->orderBy('sort_order')
    //         ->orderBy('id', 'desc')
    //         ->get();


    //     return view('pages.terms_condition.index', compact('terms'));
    // }

    public function index()
    {
        $terms = TermsCondition::with(['spot', 'service'])
            ->orderBy('sort_order')
            ->paginate(10);

        return view('pages.terms_condition.index', compact('terms'));
    }



    /**
     * Show the form for creating a new resource.
     */




    // public function create()
    // {
    //     return view('pages.terms_condition.create');
    // }

    public function create()
    {
        return view('pages.terms_condition.create', [
            'spots' => Spot::orderBy('title')->get(),
            'services' => AdditionalService::orderBy('title')->get(),
        ]);
    }



    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // $request->validate([
        //     'term_type' => 'required|in:spot,service,common',
        //     'term_description' => 'required|string',
        //     'sort_order' => 'nullable|integer',
        //     'is_active' => 'required|boolean',
        // ]);

        $request->validate([
            'term_type' => 'required|in:spot,service,common',
            'term_description' => 'required',
            'spot_id' => 'required_if:term_type,spot|nullable|exists:spots,id',
            'additional_service_id' => 'required_if:term_type,service|nullable|exists:additional_services,id',
            'sort_order' => 'nullable|integer',
            'is_active' => 'required|boolean',
        ]);


        TermsCondition::create([
            'term_type' => $request->term_type,
            'spot_id' => $request->term_type === 'spot' ? $request->spot_id : null,
            'additional_service_id' => $request->term_type === 'service' ? $request->additional_service_id : null,
            'term_title' => $request->term_title,
            'term_description' => $request->term_description,
            'sort_order' => $request->sort_order ?? 0,
            'is_active' => $request->is_active,
        ]);


        // DB::table('terms_conditions')->insert([
        //     'term_type'        => $request->term_type,
        //     'term_title'       => $request->term_title,
        //     'term_description' => $request->term_description,
        //     'sort_order'       => $request->sort_order ?? 0,
        //     'is_active'        => $request->is_active,
        //     'created_at'       => now(),
        //     'updated_at'       => now(),
        // ]);


        return redirect()
            ->route('terms-conditions.index')
            ->with('success', 'Terms & Conditions added successfully.');
    }


    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $term = DB::table('terms_conditions')->where('id', $id)->first();

        if (!$term) {
            abort(404);
        }

        return view('pages.terms_condition.show', compact('term'));
    }


    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $term = DB::table('terms_conditions')->where('id', $id)->first();
        $spots = Spot::orderBy('title')->get();
        $services = AdditionalService::orderBy('title')->get();

        if (!$term) {
            abort(404);
        }

        return view('pages.terms_condition.edit', compact('term','spots', 'services'));
    }

    



    /**
     * Update the specified resource in storage.
     */


    public function update(Request $request, $id)
    {
        // Validate input
        $request->validate([
            'term_type'        => 'required|string|max:50',
            'term_title'       => 'required|string|max:255',
            'term_description' => 'required|string',
            'sort_order'       => 'nullable|integer',
            'is_active'        => 'required|boolean',
        ]);

        // Check record exists
        $term = DB::table('terms_conditions')->where('id', $id)->first();

        if (!$term) {
            return redirect()
                ->route('terms-conditions.index')
                ->with('error', 'Terms & Conditions not found.');
        }

        // Update record
        DB::table('terms_conditions')
            ->where('id', $id)
            ->update([
                'term_type'        => $request->term_type,
                'term_title'       => $request->term_title,
                'term_description' => $request->term_description,
                'sort_order'       => $request->sort_order ?? 0,
                'is_active'        => $request->is_active,
                'updated_at'       => now(),
            ]);

        return redirect()
            ->route('terms-conditions.index')
            ->with('success', 'Terms & Conditions updated successfully.');
    }


    /**
     * Remove the specified resource from storage.
     */
    public function destroy(TermsCondition $termsCondition)
    {
        //
    }
}
